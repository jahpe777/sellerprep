import { useEffect, useState } from "react";
import { ping } from "../services/api";

export default function PingTest() {
  const [message, setMessage] = useState<string>("Loading...");

  useEffect(() => {
    ping().then((data) => setMessage(data.message));
  }, []);

  return <div>Backend says: {message}</div>;
}
