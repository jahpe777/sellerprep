import axios from "axios";

export interface PingResponse {
  message: string;
}

export const ping = async (): Promise<PingResponse> => {
  const res = await axios.get<PingResponse>("/api/ping/");
  return res.data;
};
