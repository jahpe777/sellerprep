import PingTest from "./pages/PingTest";
import AuthPage from "./pages/AuthPage";

function App() {
  return (
    <div>
      <h1>SellerPrep</h1>
      <PingTest />
      <AuthPage />
    </div>
  );
}

export default App;
